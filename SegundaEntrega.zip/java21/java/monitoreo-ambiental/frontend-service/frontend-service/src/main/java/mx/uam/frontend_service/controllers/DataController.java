package mx.uam.frontend_service.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api")
public class DataController {

    @GetMapping("/status")
    public String status() {
        return "Service is UP! " + System.currentTimeMillis();
    }

    @GetMapping("/data")
    public Object[] getData() {
        try {
            return new RestTemplate().getForObject(
                "http://storage-service:8084/api/storage/Centro", 
                Object[].class);
        } catch (Exception e) {
            return new Object[]{"Error: " + e.getMessage()};
        }
    }
}