package mx.uam.alert_service;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class AlertService {
    
    @PostMapping("/check")
    public String checkAlerts(@RequestBody SensorData data) {
        StringBuilder alerts = new StringBuilder();
        
        // Reglas de alertas
        if (data.getTemperature() > 35) {
            alerts.append("⚠️ ALERTA: Temperatura alta en ")
                 .append(data.getLocation())
                 .append(": ").append(data.getTemperature()).append("°C\n");
        }
        
        if (data.getAirQuality() > 150) {
            alerts.append("⚠️ ALERTA: Calidad de aire peligrosa en ")
                 .append(data.getLocation())
                 .append(" (AQI: ").append(data.getAirQuality()).append(")\n");
        }
        
        return alerts.isEmpty() ? "Valores normales" : alerts.toString();
    }
}