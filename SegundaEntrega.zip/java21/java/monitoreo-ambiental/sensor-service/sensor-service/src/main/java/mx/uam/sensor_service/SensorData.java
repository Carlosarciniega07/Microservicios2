package mx.uam.sensor_service;

public class SensorData {
    private String location;
    private double temperature;
    private double humidity;
    private int airQuality;

    // Constructor por defecto
    public SensorData() {}

    // Constructor completo
    public SensorData(String location, double temperature, double humidity, int airQuality) {
        this.location = location;
        this.temperature = temperature;
        this.humidity = humidity;
        this.airQuality = airQuality;
    }

    // Getters y Setters
    public String getLocation() { return location; }
    public double getTemperature() { return temperature; }
    public double getHumidity() { return humidity; }
    public int getAirQuality() { return airQuality; }

    public void setLocation(String location) { this.location = location; }
    public void setTemperature(double temperature) { this.temperature = temperature; }
    public void setHumidity(double humidity) { this.humidity = humidity; }
    public void setAirQuality(int airQuality) { this.airQuality = airQuality; }
}