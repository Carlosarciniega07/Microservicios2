package mx.uam.sensor_service;

import java.util.Random;

import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sensors")
@EnableScheduling
public class SensorController {
    private final Random random = new Random();
    private final String[] locations = {
        "Zona Norte", "Zona Sur", "Centro", 
        "Area Industrial", "Residencial Este", "Parque Central"
    };
    
    @Scheduled(fixedRate = 5000)
    @GetMapping("/data")
    public SensorData getSensorData() {
        return new SensorData(
            locations[random.nextInt(locations.length)],
            Math.round((random.nextDouble() * 40) * 10) / 10.0, // Temp 0-40°C
            Math.round((random.nextDouble() * 100) * 10) / 10.0, // Humedad 0-100%
            random.nextInt(300) // Calidad aire (0-300 AQI)
        );
    }
    
    public static class SensorData {
        private final String location;
        private final double temperature;
        private final double humidity;
        private final int airQuality;
        
        public SensorData(String location, double temperature, double humidity, int airQuality) {
            this.location = location;
            this.temperature = temperature;
            this.humidity = humidity;
            this.airQuality = airQuality;
        }
        
        // Getters
        public String getLocation() { return location; }
        public double getTemperature() { return temperature; }
        public double getHumidity() { return humidity; }
        public int getAirQuality() { return airQuality; }
    }
}