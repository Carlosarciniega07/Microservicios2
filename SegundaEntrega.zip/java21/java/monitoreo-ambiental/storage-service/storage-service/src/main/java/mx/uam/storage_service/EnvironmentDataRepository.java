package mx.uam.storage_service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvironmentDataRepository extends JpaRepository<EnvironmentData, Long> {
    List<EnvironmentData> findByLocation(String location);
}