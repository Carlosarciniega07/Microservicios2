package mx.uam.storage_service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/storage")
public class StorageController {
    
    @Autowired
    private EnvironmentDataRepository repository;

    @PostMapping("/save")
    public String saveData(@RequestBody Object sensorData) {
        // Convertir el Object a Map para acceder a los campos
        if (sensorData instanceof java.util.Map) {
            java.util.Map<?, ?> dataMap = (java.util.Map<?, ?>) sensorData;
            
            EnvironmentData envData = new EnvironmentData();
            envData.setLocation(dataMap.get("location").toString());
            envData.setTemperature(Double.parseDouble(dataMap.get("temperature").toString()));
            envData.setHumidity(Double.parseDouble(dataMap.get("humidity").toString()));
            envData.setAirQuality(Integer.parseInt(dataMap.get("airQuality").toString()));
            
            repository.save(envData);
            return "Datos guardados para: " + envData.getLocation();
        }
        return "Error: Formato de datos no válido";
    }

    @GetMapping("/{location}")
    public List<EnvironmentData> getByLocation(@PathVariable String location) {
        return repository.findByLocation(location);
    }

    @GetMapping("/status")
    public String status() {
        return "Storage Service OK";
    }
}