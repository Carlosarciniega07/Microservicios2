package mx;

public class SensorData {

}
