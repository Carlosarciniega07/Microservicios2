package mx.uam.storage_service;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "environment_data")
public class EnvironmentData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String location;
    private double temperature;
    private double humidity;
    private int airQuality;
    private final LocalDateTime timestamp = LocalDateTime.now();
    
    // Getters y Setter
    public Long getId() { return id; }
    public String getLocation() { return location; }
    public double getTemperature() { return temperature; }
    public double getHumidity() { return humidity; }
    public int getAirQuality() { return airQuality; }
    public LocalDateTime getTimestamp() { return timestamp; }
    
    public void setLocation(String location) { this.location = location; }
    public void setTemperature(double temperature) { this.temperature = temperature; }
    public void setHumidity(double humidity) { this.humidity = humidity; }
    public void setAirQuality(int airQuality) { this.airQuality = airQuality; }
}